// Import Firebase SDK (Modular v9)
// Using CDN for "No npm packages" rule, but accessible via standard ES modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { 
    getAuth, 
    createUserWithEmailAndPassword, 
    signInWithEmailAndPassword, 
    signOut, 
    onAuthStateChanged,
    updateProfile
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";
import { 
    getDatabase, 
    ref, 
    set, 
    push, 
    onValue, 
    serverTimestamp,
    query,
    orderByChild
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";

// ==========================================
// 1. FIREBASE CONFIGURATION (PLACEHOLDER)
// ==========================================
// TODO: Replace the object below with your actual Firebase config
// You can get this from the Firebase Console -> Project Settings -> General -> Your apps
const firebaseConfig = {
    apiKey: "AIzaSyCaW-8Jt-1CnnH667qnNJxSyM_e8iDKKVY",
    authDomain: "facemash-eba16.firebaseapp.com",
    databaseURL: "https://facemash-eba16-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "facemash-eba16",
    storageBucket: "facemash-eba16.firebasestorage.app",
    messagingSenderId: "878453352981",
    appId: "1:878453352981:web:811987d9cf1756a6303c1c"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);

// ==========================================
// 2. STATE MANAGEMENT
// ==========================================
let currentUser = null;
let selectedUser = null;
let allUsers = {};
let recentChats = {};

// ==========================================
// 3. DOM ELEMENTS
// ==========================================
// Screens
const authContainer = document.getElementById('auth-container');
const mainContainer = document.getElementById('main-container');

// Tabs
const tabChats = document.getElementById('tab-chats');
const tabPosts = document.getElementById('tab-posts');
const sidebarChats = document.getElementById('sidebar-chats');
const sidebarPosts = document.getElementById('sidebar-posts');
const chatView = document.getElementById('chat-view');
const feedView = document.getElementById('feed-view');

// Auth Forms
const loginForm = document.getElementById('login-form');
const signupForm = document.getElementById('signup-form');
const linkSignup = document.getElementById('link-signup');
const linkLogin = document.getElementById('link-login');

// Inputs
const loginEmail = document.getElementById('login-email');
const loginPass = document.getElementById('login-password');
const signupName = document.getElementById('signup-name');
const signupBio = document.getElementById('signup-bio');
const signupEmail = document.getElementById('signup-email');
const signupPass = document.getElementById('signup-password');

// User Search
const userSearch = document.getElementById('user-search');

// Post Elements
const postInput = document.getElementById('post-input');
const postImageInput = document.getElementById('post-image-input');
const imagePreview = document.getElementById('image-preview');
const previewImg = imagePreview.querySelector('img');
const btnRemovePreview = document.getElementById('btn-remove-preview');
const postLinkUrl = document.getElementById('post-link-url');
const btnPost = document.getElementById('btn-post');
const postsList = document.getElementById('posts-list');

let selectedImageData = null;

// Buttons
const btnLogin = document.getElementById('btn-login');
const btnSignup = document.getElementById('btn-signup');
const btnLogout = document.getElementById('btn-logout');
const btnSend = document.getElementById('btn-send');

// Profile Elements
const myAvatar = document.getElementById('my-avatar');
const myName = document.getElementById('my-name');
const myBio = document.getElementById('my-bio');

// Settings Elements
const btnSettings = document.getElementById('btn-settings');
const settingsModal = document.getElementById('settings-modal');
const settingsAvatarPreview = document.getElementById('settings-avatar-preview');
const dpInput = document.getElementById('dp-input');
const settingsBioInput = document.getElementById('settings-bio-input');
const btnCloseSettings = document.getElementById('btn-close-settings');
const btnSaveSettings = document.getElementById('btn-save-settings');

let selectedDpData = null;

// User List
const usersList = document.getElementById('users-list');
const recentChatsList = document.getElementById('recent-chats-list');

// Chat Elements
const noChatSelected = document.getElementById('no-chat-selected');
const chatInterface = document.getElementById('chat-interface');
const chatAvatar = document.getElementById('chat-avatar');
const chatUsername = document.getElementById('chat-username');
const messagesContainer = document.getElementById('messages-container');
const messageInput = document.getElementById('message-input');

// ==========================================
// 4. AUTHENTICATION LOGIC
// ==========================================

// Toggle between Login/Signup
linkSignup.addEventListener('click', (e) => {
    e.preventDefault();
    loginForm.classList.add('hidden');
    signupForm.classList.remove('hidden');
});

linkLogin.addEventListener('click', (e) => {
    e.preventDefault();
    signupForm.classList.add('hidden');
    loginForm.classList.remove('hidden');
});

// Sign Up
btnSignup.addEventListener('click', async () => {
    const email = signupEmail.value;
    const password = signupPass.value;
    const name = signupName.value;
    const bio = signupBio.value;

    if (!email || !password || !name) {
        alert("Please fill in all fields");
        return;
    }

    try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;

        // Update Auth Profile
        await updateProfile(user, { displayName: name });

        // Save User to Realtime Database
        await set(ref(db, 'users/' + user.uid), {
            uid: user.uid,
            displayName: name,
            email: email,
            bio: bio,
            photoURL: '' // Placeholder
        });

        console.log("User registered:", user);
    } catch (error) {
        alert("Error signing up: " + error.message);
    }
});

// Login
btnLogin.addEventListener('click', async () => {
    const email = loginEmail.value;
    const password = loginPass.value;

    if (!email || !password) {
        alert("Please enter email and password");
        return;
    }

    try {
        await signInWithEmailAndPassword(auth, email, password);
    } catch (error) {
        alert("Error logging in: " + error.message);
    }
});

// Logout
btnLogout.addEventListener('click', () => {
    signOut(auth);
    selectedUser = null;
    chatInterface.classList.add('hidden');
    noChatSelected.classList.remove('hidden');
});

// Auth State Observer
onAuthStateChanged(auth, (user) => {
    if (user) {
        // User is signed in
        currentUser = user;
        authContainer.classList.add('hidden');
        mainContainer.classList.remove('hidden');
        loadUserProfile();
        loadUsersList();
        loadRecentChats();
        loadPosts();
    } else {
        // User is signed out
        currentUser = null;
        authContainer.classList.remove('hidden');
        mainContainer.classList.add('hidden');
    }
});

// ==========================================
// 5. NAVIGATION LOGIC
// ==========================================
tabChats.addEventListener('click', () => {
    tabChats.classList.add('active');
    tabPosts.classList.remove('active');
    sidebarChats.classList.remove('hidden');
    sidebarPosts.classList.add('hidden');
    chatView.classList.remove('hidden');
    feedView.classList.add('hidden');
});

tabPosts.addEventListener('click', () => {
    tabPosts.classList.add('active');
    tabChats.classList.remove('active');
    sidebarPosts.classList.remove('hidden');
    sidebarChats.classList.add('hidden');
    feedView.classList.remove('hidden');
    chatView.classList.add('hidden');
});

// ==========================================
// 6. APP LOGIC
// ==========================================

// Settings Modal Logic
btnSettings.addEventListener('click', () => {
    settingsBioInput.value = myBio.textContent;
    renderAvatar(settingsAvatarPreview, currentUser.uid);
    settingsModal.classList.remove('hidden');
});

btnCloseSettings.addEventListener('click', () => {
    settingsModal.classList.add('hidden');
    selectedDpData = null;
});

dpInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
            selectedDpData = event.target.result;
            settingsAvatarPreview.innerHTML = `<img src="${selectedDpData}" alt="DP Preview">`;
        };
        reader.readAsDataURL(file);
    }
});

btnSaveSettings.addEventListener('click', async () => {
    const newBio = settingsBioInput.value.trim();
    
    const updates = {
        bio: newBio
    };

    if (selectedDpData) {
        updates.photoURL = selectedDpData;
    }

    try {
        const userRef = ref(db, 'users/' + currentUser.uid);
        await set(userRef, {
            ...allUsers[currentUser.uid],
            ...updates
        });
        settingsModal.classList.add('hidden');
        selectedDpData = null;
    } catch (error) {
        alert("Error saving settings: " + error.message);
    }
});

function renderAvatar(container, uid) {
    const user = allUsers[uid] || (uid === currentUser.uid ? { displayName: currentUser.displayName, photoURL: '' } : null);
    if (!user) return;

    if (user.photoURL) {
        container.innerHTML = `<img src="${user.photoURL}" alt="${user.displayName}">`;
    } else {
        container.textContent = user.displayName.charAt(0).toUpperCase();
        container.innerHTML = user.displayName.charAt(0).toUpperCase();
    }
}

// Load Current User Profile
function loadUserProfile() {
    const userRef = ref(db, 'users/' + currentUser.uid);
    onValue(userRef, (snapshot) => {
        const data = snapshot.val();
        if (data) {
            allUsers[currentUser.uid] = data;
            myName.textContent = data.displayName;
            myBio.textContent = data.bio || "";
            renderAvatar(myAvatar, currentUser.uid);
        }
    });
}

// Load List of Users
function loadUsersList() {
    const usersRef = ref(db, 'users');
    onValue(usersRef, (snapshot) => {
        allUsers = snapshot.val() || {};
        renderUsers();
    });
}

userSearch.addEventListener('input', renderUsers);

function renderUsers() {
    usersList.innerHTML = '';
    const searchTerm = userSearch.value.toLowerCase();

    Object.values(allUsers).forEach((user) => {
        if (user.uid === currentUser.uid) return;
        if (searchTerm && !user.displayName.toLowerCase().includes(searchTerm)) return;

        const li = createUserItem(user);
        usersList.appendChild(li);
    });
}

function createUserItem(user, lastMsg = null) {
    const li = document.createElement('li');
    li.className = 'user-item';
    if (selectedUser && selectedUser.uid === user.uid) li.classList.add('active');

    const avatarDiv = document.createElement('div');
    avatarDiv.className = 'avatar';
    renderAvatar(avatarDiv, user.uid);

    li.appendChild(avatarDiv);

    const infoDiv = document.createElement('div');
    infoDiv.className = 'info';
    infoDiv.innerHTML = `
        <h3>${user.displayName}</h3>
        ${lastMsg ? `<p class="recent-msg">${lastMsg.text}</p>` : `<p>${user.bio || ''}</p>`}
    `;
    li.appendChild(infoDiv);

    li.onclick = () => selectUser(user);
    return li;
}

// Recent Chats
function loadRecentChats() {
    const chatsRef = ref(db, 'chats');
    onValue(chatsRef, (snapshot) => {
        const chats = snapshot.val() || {};
        recentChatsList.innerHTML = '';
        
        const myRecentChats = [];

        Object.keys(chats).forEach(chatId => {
            if (chatId.includes(currentUser.uid)) {
                const otherUid = chatId.replace(currentUser.uid, '').replace('_', '');
                const messages = chats[chatId].messages;
                if (messages) {
                    const msgArray = Object.values(messages);
                    const lastMsg = msgArray[msgArray.length - 1];
                    myRecentChats.push({
                        uid: otherUid,
                        lastMsg: lastMsg
                    });
                }
            }
        });

        // Sort by most recent
        myRecentChats.sort((a, b) => b.lastMsg.timestamp - a.lastMsg.timestamp);

        myRecentChats.forEach(item => {
            const user = allUsers[item.uid];
            if (user) {
                const li = createUserItem(user, item.lastMsg);
                recentChatsList.appendChild(li);
            }
        });
    });
}

// Select User to Chat
function selectUser(user) {
    selectedUser = user;
    
    // Switch to chat view if in feed
    tabChats.click();

    // Update UI
    noChatSelected.classList.add('hidden');
    chatInterface.classList.remove('hidden');
    chatUsername.textContent = user.displayName;
    renderAvatar(chatAvatar, user.uid);

    renderUsers(); // Refresh active state
    loadMessages();
}

// Load Messages
function loadMessages() {
    const chatId = [currentUser.uid, selectedUser.uid].sort().join('_');
    const messagesRef = ref(db, `chats/${chatId}/messages`);
    
    onValue(messagesRef, (snapshot) => {
        messagesContainer.innerHTML = '';
        const messages = snapshot.val();
        
        if (messages) {
            Object.values(messages).forEach(msg => {
                renderMessage(msg);
            });
            scrollToBottom();
        }
    });
}

function renderMessage(msg) {
    const div = document.createElement('div');
    const isMe = msg.senderId === currentUser.uid;
    
    div.className = `message ${isMe ? 'sent' : 'received'}`;
    div.innerHTML = `
        <div class="content">${msg.text}</div>
        <span class="message-time">${new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
    `;
    messagesContainer.appendChild(div);
}

// Send Message
function sendMessage() {
    if (!messageInput.value.trim() || !selectedUser) return;

    const chatId = [currentUser.uid, selectedUser.uid].sort().join('_');
    const messagesRef = ref(db, `chats/${chatId}/messages`);
    
    const newMessageRef = push(messagesRef);
    set(newMessageRef, {
        senderId: currentUser.uid,
        text: messageInput.value.trim(),
        timestamp: serverTimestamp()
    });

    messageInput.value = '';
}

btnSend.addEventListener('click', sendMessage);
messageInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sendMessage();
});

function scrollToBottom() {
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

// ==========================================
// 7. POSTING SYSTEM LOGIC
// ==========================================

postImageInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
            selectedImageData = event.target.result;
            previewImg.src = selectedImageData;
            imagePreview.classList.remove('hidden');
        };
        reader.readAsDataURL(file);
    }
});

btnRemovePreview.addEventListener('click', () => {
    selectedImageData = null;
    postImageInput.value = '';
    imagePreview.classList.add('hidden');
});

btnPost.addEventListener('click', async () => {
    const text = postInput.value.trim();
    const linkUrl = postLinkUrl.value.trim();

    if (!text && !selectedImageData && !linkUrl) return;

    const postsRef = ref(db, 'posts');
    const newPostRef = push(postsRef);
    
    await set(newPostRef, {
        id: newPostRef.key,
        authorId: currentUser.uid,
        authorName: currentUser.displayName,
        content: text,
        mediaUrl: selectedImageData || linkUrl,
        timestamp: serverTimestamp(),
        likes: {}
    });

    postInput.value = '';
    postLinkUrl.value = '';
    btnRemovePreview.click();
});

function loadPosts() {
    const postsRef = ref(db, 'posts');
    onValue(postsRef, (snapshot) => {
        postsList.innerHTML = '';
        const posts = snapshot.val();
        if (posts) {
            // Sort posts by newest first
            const sortedPosts = Object.values(posts).sort((a, b) => b.timestamp - a.timestamp);
            sortedPosts.forEach(post => renderPost(post));
        }
    });
}

function renderPost(post) {
    const card = document.createElement('div');
    card.className = 'post-card';
    
    const isLiked = post.likes && post.likes[currentUser.uid];
    const likeCount = post.likes ? Object.keys(post.likes).length : 0;

    let mediaHtml = '';
    if (post.mediaUrl) {
        if (post.mediaUrl.startsWith('data:image')) {
            mediaHtml = `<div class="post-media"><img src="${post.mediaUrl}" alt="Post image"></div>`;
        } else if (post.mediaUrl.match(/\.(jpeg|jpg|gif|png)$/) != null) {
            mediaHtml = `<div class="post-media"><img src="${post.mediaUrl}" alt="Post image"></div>`;
        } else {
            mediaHtml = `<div class="post-media"><a href="${post.mediaUrl}" target="_blank" style="color:var(--primary)">${post.mediaUrl}</a></div>`;
        }
    }

    const authorAvatar = document.createElement('div');
    authorAvatar.className = 'avatar small';
    const author = allUsers[post.authorId];
    if (author && author.photoURL) {
        authorAvatar.innerHTML = `<img src="${author.photoURL}" alt="${post.authorName}">`;
    } else {
        authorAvatar.textContent = post.authorName.charAt(0).toUpperCase();
    }

    card.innerHTML = `
        <div class="post-header">
            ${authorAvatar.outerHTML}
            <div>
                <div class="post-author">${post.authorName}</div>
                <div class="post-time">${new Date(post.timestamp).toLocaleString()}</div>
            </div>
        </div>
        <div class="post-content">${post.content}</div>
        ${mediaHtml}
        <div class="post-actions">
            <button class="action-btn ${isLiked ? 'liked' : ''}" onclick="toggleLike('${post.id}')">
                <span>❤️</span> ${likeCount}
            </button>
            <button class="action-btn" onclick="focusComment('${post.id}')">
                <span>💬</span> Comment
            </button>
        </div>
        <div class="comments-section" id="comments-${post.id}">
            <!-- Comments injected here -->
        </div>
        <div class="comment-input-area">
            <input type="text" id="comment-input-${post.id}" placeholder="Write a comment...">
            <button onclick="addComment('${post.id}')">Add</button>
        </div>
    `;

    postsList.appendChild(card);
    loadComments(post.id);
}

// Global scope functions for onclick handlers
window.toggleLike = (postId) => {
    const likeRef = ref(db, `posts/${postId}/likes/${currentUser.uid}`);
    onValue(ref(db, `posts/${postId}/likes/${currentUser.uid}`), (snapshot) => {
        if (snapshot.exists()) {
            set(likeRef, null); // Unlike
        } else {
            set(likeRef, true); // Like
        }
    }, { onlyOnce: true });
};

window.focusComment = (postId) => {
    document.getElementById(`comment-input-${postId}`).focus();
};

window.addComment = (postId) => {
    const input = document.getElementById(`comment-input-${postId}`);
    const text = input.value.trim();
    if (!text) return;

    const commentsRef = ref(db, `posts/${postId}/comments`);
    const newCommentRef = push(commentsRef);
    set(newCommentRef, {
        authorName: currentUser.displayName,
        text: text,
        timestamp: serverTimestamp()
    });
    input.value = '';
};

function loadComments(postId) {
    const commentsRef = ref(db, `posts/${postId}/comments`);
    const container = document.getElementById(`comments-${postId}`);
    onValue(commentsRef, (snapshot) => {
        container.innerHTML = '';
        const comments = snapshot.val();
        if (comments) {
            Object.values(comments).forEach(comment => {
                const div = document.createElement('div');
                div.className = 'comment';
                div.innerHTML = `<span class="comment-author">${comment.authorName}:</span><span>${comment.text}</span>`;
                container.appendChild(div);
            });
        }
    });
}
